/**
 * Created by lijun on 2016/12/4.
 */
import './main.css';
import Drag from './drag';

const create = (el, options) => Drag.create(el, options);
export default create;
