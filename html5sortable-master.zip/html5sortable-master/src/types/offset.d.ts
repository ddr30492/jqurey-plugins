/*
  * Offset object interface
*/
interface offsetObject {
    'left': number,
    'right': number,
    'top': number,
    'bottom': number
}