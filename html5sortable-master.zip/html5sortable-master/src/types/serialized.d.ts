/*
  * Serialized Item interface
*/
interface serializedItem {
    parent: HTMLElement,
    node: HTMLElement,
    html: string,
    index: number
}