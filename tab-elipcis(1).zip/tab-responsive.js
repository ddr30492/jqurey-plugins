function autocollapse() {

	if ($('.vc_tta-tabs-list').length > 0) {
		var wcTabs = $('.vc_tta-tabs-list');
		$(wcTabs).addClass("nav nav-tabs tab-list");
		//$(wcTabs).css('overflow','inherit');
	};

	if ($('.tab-list').length > 0 || $('.tab-list-new').length > 0) {
		var tabs_all = $('.tab-list, .tab-list-new');
		tabs_all.each(function(){
			var tabs = $(this);
			//var tabsHeight = tabs.innerHeight();
			var tabsHeight = tabs.height();
			var liHeight = tabs.find('li:first-child a').outerHeight();

			if (tabs.find('.last-tab').length <= 0) {
				tabs.append('<li class="cbrt-tab-last vc_tta-tab last-tab"><a class="more-link dropdown-toggle" data-toggle="dropdown" href="#">More <span class="caret"></span></a><ul class="dropdown-menu collapsed"></ul></li>');
				tabs.find('li>ul.collapsed').css({
						'z-index': '9999',
						'position': 'relative'
				});
			}
			
			if(tabs.is(':hidden')){return false;}
			
			function autocollapseInner(){
				if (tabsHeight > liHeight) {
					tabs.find('.last-tab').show();
					while (tabsHeight > liHeight) {
						var children = tabs.children('li:not(:last-child)');
						var count = children.size();
						$(children[count - 1]).prependTo(tabs.find('.dropdown-menu'));

						tabsHeight = tabs.height();
					}
				}
				else {
					while (tabsHeight <= liHeight && (tabs.children('li').size() > 0)) {

						var collapsed = tabs.find('.dropdown-menu').children('li');
						var count = collapsed.size();
						if (count <= 0) {
							tabs.find('.last-tab').hide();
							break;
						}
						$(collapsed[0]).insertBefore(tabs.children('li:last-child'));
						tabsHeight = tabs.height();
					}
					if (tabsHeight > liHeight) { // double chk height again
						autocollapseInner();
					}
				}
			}

			autocollapseInner();

		});
	};

};
autocollapse(); // when document first loads
$(window).on('resize', autocollapse); // when window is resized